package com.godhands;

import com.godhands.item.GodHandsItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GodHandsMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GodHandsMod.MODID);

    public static final RegistryObject<Item> GOD_HANDS = ITEMS.register("god_hands", GodHandsItem::new);

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.godhands"))
                    .icon(() -> new ItemStack(GOD_HANDS.get()))
                    .displayItems((params, output) -> output.accept(GOD_HANDS.get()))
                    .build());
}
