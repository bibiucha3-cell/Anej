package com.godhands.power;

import com.godhands.GodHandsMod;
import com.godhands.item.GodHandsItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Lógica do poder de telecinese (roda só no servidor). */
@Mod.EventBusSubscriber(modid = GodHandsMod.MODID)
public class GrabManager {
    private static final Map<UUID, Grab> GRABS = new HashMap<>();
    private static final double REACH = 28.0;
    private static final double MIN_DIST = 2.5;

    private static class Grab {
        final Entity entity;
        double distance;
        final boolean wasNoGravity;
        final boolean wasGlowing;
        int age = 0;

        Grab(Entity entity, double distance) {
            this.entity = entity;
            this.distance = distance;
            this.wasNoGravity = entity.isNoGravity();
            this.wasGlowing = entity.hasGlowingTag();
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        boolean active = player.isShiftKeyDown() && !player.isSpectator()
                && GodHandsItem.isHolding(player, Power.TELEKINESIS);
        Grab grab = GRABS.get(player.getUUID());
        if (!active) {
            if (grab != null) release(player);
            return;
        }
        if (grab == null) tryGrab(player);
        else update(player, grab);
    }

    private static boolean isGrabbedByOther(Entity e, ServerPlayer self) {
        for (Map.Entry<UUID, Grab> en : GRABS.entrySet()) {
            if (!en.getKey().equals(self.getUUID()) && en.getValue().entity == e) return true;
        }
        return false;
    }

    private static void tryGrab(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = eye.add(look.scale(REACH));

        BlockHitResult bhit = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE,
                ClipContext.Fluid.NONE, player));
        double blockDistSqr = bhit.getType() == HitResult.Type.MISS
                ? Double.MAX_VALUE : bhit.getLocation().distanceToSqr(eye);

        AABB box = player.getBoundingBox().expandTowards(look.scale(REACH)).inflate(1.0);
        EntityHitResult ehit = ProjectileUtil.getEntityHitResult(player, eye, end, box,
                e -> !e.isSpectator() && !(e instanceof Player) && (e.isPickable() || e instanceof ItemEntity),
                REACH * REACH);

        if (ehit != null && ehit.getLocation().distanceToSqr(eye) < blockDistSqr
                && !isGrabbedByOther(ehit.getEntity(), player)) {
            double d = Mth.clamp(ehit.getLocation().distanceTo(eye), MIN_DIST, REACH);
            start(player, ehit.getEntity(), d);
            return;
        }

        if (bhit.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = bhit.getBlockPos();
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || state.getDestroySpeed(level, pos) < 0 || level.getBlockEntity(pos) != null) return;
            double d = Mth.clamp(Math.sqrt(blockDistSqr), MIN_DIST, REACH);
            FallingBlockEntity block = FallingBlockEntity.fall(level, pos, state);
            block.time = 1;
            start(player, block, d);
        }
    }

    private static void start(ServerPlayer player, Entity target, double distance) {
        Grab grab = new Grab(target, distance);
        GRABS.put(player.getUUID(), grab);
        target.setNoGravity(true);
        target.setGlowingTag(true);
        target.fallDistance = 0;

        ServerLevel level = player.serverLevel();
        Vec3 c = target.getBoundingBox().getCenter();
        level.playSound(null, player.blockPosition(), SoundEvents.ILLUSIONER_CAST_SPELL, SoundSource.PLAYERS, 0.9f, 1.4f);
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.6f, 1.8f);
        level.playSound(null, target.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0f, 1.2f);
        level.sendParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 30, 0.4, 0.4, 0.4, 0.3);
        level.sendParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 20, 0.3, 0.3, 0.3, 0.12);
    }

    private static void update(ServerPlayer player, Grab g) {
        Entity e = g.entity;
        if (e.isRemoved() || e.level() != player.level()) {
            GRABS.remove(player.getUUID());
            return;
        }
        ServerLevel level = player.serverLevel();
        g.age++;

        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 target = eye.add(look.scale(g.distance)).add(0, Math.sin(g.age * 0.12) * 0.06, 0);
        Vec3 center = e.getBoundingBox().getCenter();
        Vec3 diff = target.subtract(center);

        if (e instanceof FallingBlockEntity fb) {
            Vec3 step = diff.scale(0.45);
            fb.setDeltaMovement(Vec3.ZERO);
            fb.time = 1;
            fb.setPos(fb.getX() + step.x, fb.getY() + step.y, fb.getZ() + step.z);
        } else {
            Vec3 v = diff.scale(0.4);
            if (v.lengthSqr() > 4.0) v = v.normalize().scale(2.0);
            e.setDeltaMovement(v);
            e.hurtMarked = true;
            if (e instanceof Mob mob) mob.getNavigation().stop();
        }
        e.fallDistance = 0;
        center = e.getBoundingBox().getCenter();

        // ---------- efeitos ----------
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        Vec3 hand = eye.add(look.scale(0.8)).add(right.scale(0.35)).add(0, -0.3, 0);

        if (g.age % 2 == 0) {
            Vec3 d = center.subtract(hand);
            double len = d.length();
            if (len > 0.1) {
                Vec3 dir = d.scale(1.0 / len);
                for (double t = 0; t < len; t += 1.0) {
                    Vec3 p = hand.add(dir.scale(t));
                    level.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.03, 0.03, 0.03, 0.0);
                }
                if (g.age % 4 == 0) {
                    Vec3 p = hand.add(dir.scale(len * level.random.nextDouble()));
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 2, 0.1, 0.1, 0.1, 0.1);
                }
            }
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, hand.x, hand.y, hand.z, 2, 0.08, 0.08, 0.08, 0.05);
        }

        double radius = Math.max(e.getBbWidth(), 0.6) * 0.8 + 0.3;
        double ang = g.age * 0.35;
        for (int i = 0; i < 3; i++) {
            double a = ang + i * Math.PI * 2 / 3;
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    center.x + Math.cos(a) * radius,
                    center.y + Math.sin(g.age * 0.1 + i) * 0.3,
                    center.z + Math.sin(a) * radius, 1, 0, 0, 0, 0);
        }
        if (g.age % 3 == 0) {
            level.sendParticles(ParticleTypes.GLOW, center.x, center.y, center.z, 2, 0.3, 0.3, 0.3, 0.02);
        }
        if (g.age % 25 == 0) {
            level.playSound(null, e.blockPosition(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 0.25f, 1.9f);
        }
    }

    public static void adjustDistance(ServerPlayer player, float delta) {
        Grab g = GRABS.get(player.getUUID());
        if (g == null) return;
        g.distance = Mth.clamp(g.distance + delta * 1.2, MIN_DIST, REACH);
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                SoundSource.PLAYERS, 0.3f, 1.2f + (float) (g.distance / REACH));
    }

    public static void release(ServerPlayer player) {
        Grab g = GRABS.remove(player.getUUID());
        if (g == null) return;
        Entity e = g.entity;
        ServerLevel level = player.serverLevel();
        if (!e.isRemoved()) {
            e.setNoGravity(g.wasNoGravity);
            e.setGlowingTag(g.wasGlowing);
            e.setDeltaMovement(player.getLookAngle().scale(0.5));
            e.hurtMarked = true;
            e.fallDistance = 0;
            if (e instanceof FallingBlockEntity fb) fb.time = 1;
            Vec3 c = e.getBoundingBox().getCenter();
            level.sendParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 25, 0.3, 0.3, 0.3, 0.15);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 20, 0.4, 0.4, 0.4, 0.25);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.6f, 1.7f);
        level.playSound(null, player.blockPosition(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.PLAYERS, 0.8f, 1.3f);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) release(sp);
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) release(sp);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) release(sp);
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        GRABS.clear();
    }
}
