package com.godhands.power;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/** Para adicionar poderes novos: crie uma entrada aqui + lang + lógica no servidor. */
public enum Power {
    NONE("none", Items.BARRIER, 0xFF6B6B),
    TELEKINESIS("telekinesis", Items.ENDER_EYE, 0x5CE1FF);

    public final String key;
    public final Item icon;
    public final int color;

    Power(String key, Item icon, int color) {
        this.key = key;
        this.icon = icon;
        this.color = color;
    }

    public static Power byId(int id) {
        Power[] v = values();
        return id >= 0 && id < v.length ? v[id] : NONE;
    }
}
