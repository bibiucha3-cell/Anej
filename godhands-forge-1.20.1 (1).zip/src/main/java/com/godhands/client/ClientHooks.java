package com.godhands.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;

public class ClientHooks {
    public static void openWheel(InteractionHand hand) {
        Minecraft.getInstance().setScreen(new PowerWheelScreen(hand));
    }
}
