package com.godhands.client;

import com.godhands.GodHandsMod;
import com.godhands.item.GodHandsItem;
import com.godhands.network.DistancePacket;
import com.godhands.network.ModNetwork;
import com.godhands.power.Power;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GodHandsMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientEvents {
    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null || !p.isShiftKeyDown()) return;
        if (!GodHandsItem.isHolding(p, Power.TELEKINESIS)) return;
        double d = event.getScrollDelta();
        if (d == 0) return;
        event.setCanceled(true);
        ModNetwork.CH.sendToServer(new DistancePacket(d > 0 ? 1f : -1f));
    }
}
