package com.godhands.client;

import com.godhands.item.GodHandsItem;
import com.godhands.network.ModNetwork;
import com.godhands.network.SelectPowerPacket;
import com.godhands.power.Power;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix4f;

/** Roda de poderes (radial menu) com animação de abertura. */
public class PowerWheelScreen extends Screen {
    private static final float INNER = 38f;
    private static final float OUTER = 96f;

    private final InteractionHand hand;
    private final Power[] powers = Power.values();
    private final long openTime = Util.getMillis();
    private int hovered = -1;
    private Power current = Power.NONE;

    public PowerWheelScreen(InteractionHand hand) {
        super(Component.translatable("screen.godhands.wheel"));
        this.hand = hand;
    }

    @Override
    protected void init() {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) current = GodHandsItem.getPower(p.getItemInHand(hand));
        Minecraft.getInstance().getSoundManager().play(
                SimpleSoundInstance.forUI(SoundEvents.AMETHYST_BLOCK_RESONATE, 1.4f, 0.8f));
    }

    @Override
    public void tick() {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null || !(p.getItemInHand(hand).getItem() instanceof GodHandsItem)) onClose();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        float t = Mth.clamp((Util.getMillis() - openTime) / 220f, 0f, 1f);
        float ease = 1f - (1f - t) * (1f - t) * (1f - t);

        g.fillGradient(0, 0, width, height,
                ((int) (ease * 0x99) << 24) | 0x050818, ((int) (ease * 0xCC) << 24) | 0x0B1230);

        float cx = width / 2f, cy = height / 2f;
        float inner = INNER * ease, outer = OUTER * ease;
        int n = powers.length;
        float seg = Mth.TWO_PI / n;

        // setor sob o mouse (setor i fica centrado no ângulo i*seg, 0 = topo, sentido horário)
        float dx = mx - cx, dy = my - cy;
        float dist = Mth.sqrt(dx * dx + dy * dy);
        int newHover = -1;
        if (dist > inner * 0.5f && dist < OUTER + 60) {
            float a = (float) Math.atan2(dx, -dy) + seg / 2f;
            while (a < 0) a += Mth.TWO_PI;
            newHover = ((int) (a / seg)) % n;
        }
        if (newHover != hovered && newHover >= 0) {
            Minecraft.getInstance().getSoundManager().play(
                    SimpleSoundInstance.forUI(SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f, 0.6f));
        }
        hovered = newHover;

        sector(g, cx, cy, 0, inner * 0.8f, 0, Mth.TWO_PI, 0x33FFFFFF);

        for (int i = 0; i < n; i++) {
            Power pw = powers[i];
            boolean hov = i == hovered;
            float outerR = hov ? outer + 8 : outer;
            float a0 = i * seg - seg / 2f + 0.03f, a1 = i * seg + seg / 2f - 0.03f;
            int rgb = pw.color & 0xFFFFFF;
            sector(g, cx, cy, inner, outerR, a0, a1, ((hov ? 0xAA : 0x66) << 24) | rgb);
            if (pw == current) {
                sector(g, cx, cy, outerR + 3, outerR + 6, a0, a1, 0xFF000000 | rgb);
            }
            float mid = i * seg;
            float rm = (inner + outerR) / 2f;
            float ix = cx + Mth.sin(mid) * rm, iy = cy - Mth.cos(mid) * rm;
            float s = (hov ? 1.9f : 1.5f) * ease;
            g.pose().pushPose();
            g.pose().translate(ix, iy, 0);
            g.pose().scale(s, s, 1f);
            g.renderItem(new ItemStack(pw.icon), -8, -8);
            g.pose().popPose();
        }

        Power shown = hovered >= 0 ? powers[hovered] : current;
        g.drawCenteredString(font, Component.translatable("power.godhands." + shown.key),
                (int) cx, (int) cy - 4, 0xFF000000 | shown.color);
        g.drawCenteredString(font, title, (int) cx, (int) (cy - OUTER - 26), 0xFFFFFF);
        if (hovered >= 0) {
            g.drawCenteredString(font, Component.translatable("screen.godhands.select"),
                    (int) cx, (int) (cy + OUTER + 22), 0xAAAAAA);
        }
    }

    private void sector(GuiGraphics g, float cx, float cy, float r0, float r1, float a0, float a1, int argb) {
        Matrix4f m = g.pose().last().pose();
        int alpha = argb >>> 24 & 255, red = argb >> 16 & 255, green = argb >> 8 & 255, blue = argb & 255;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_COLOR);
        int steps = Math.max(8, (int) ((a1 - a0) * 24));
        for (int s = 0; s <= steps; s++) {
            float a = a0 + (a1 - a0) * s / steps;
            float sx = Mth.sin(a), sy = -Mth.cos(a);
            buf.vertex(m, cx + sx * r1, cy + sy * r1, 0).color(red, green, blue, alpha).endVertex();
            buf.vertex(m, cx + sx * r0, cy + sy * r0, 0).color(red, green, blue, alpha).endVertex();
        }
        Tesselator.getInstance().end();
        RenderSystem.disableBlend();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && hovered >= 0) {
            ModNetwork.CH.sendToServer(new SelectPowerPacket(powers[hovered].ordinal(), hand == InteractionHand.OFF_HAND));
            onClose();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
