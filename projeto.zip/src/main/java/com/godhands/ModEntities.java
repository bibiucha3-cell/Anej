package com.godhands;

import com.godhands.entity.SunEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, GodHandsMod.MODID);

    public static final RegistryObject<EntityType<SunEntity>> SUN = ENTITIES.register("sun", () ->
            EntityType.Builder.<SunEntity>of(SunEntity::new, MobCategory.MISC)
                    .sized(2f, 2f).clientTrackingRange(12).updateInterval(1)
                    .fireImmune().noSave()
                    .build(new ResourceLocation(GodHandsMod.MODID, "sun").toString()));
}
