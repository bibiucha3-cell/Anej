package com.godhands.power;

import com.godhands.ModParticles;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.PartEntity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Void: o alvo vira cinzas e se dissolve (funciona com qualquer entidade, inclusive de outros mods). */
public class VoidPower implements PowerLogic {
    private static final double RANGE = 48.0;
    private static final int DURATION = 40;
    private static final List<Dissolve> LIST = new ArrayList<>();

    private static class Dissolve {
        final Entity entity;
        final Vec3 axis;
        int age = 0;

        Dissolve(Entity entity, Vec3 axis) {
            this.entity = entity;
            this.axis = axis;
        }
    }

    private static boolean isDissolving(Entity e) {
        for (Dissolve d : LIST) if (d.entity == e) return true;
        return false;
    }

    @Override
    public void start(ServerPlayer p) {
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.5f, 0.5f);
    }

    @Override
    public void tick(ServerPlayer p, int age) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        Vec3 hand = eye.add(look.scale(0.8)).add(right.scale(0.35)).add(0, -0.3, 0);
        if (age % 2 == 0) {
            level.sendParticles(ParticleTypes.PORTAL, hand.x, hand.y, hand.z, 6, 0.1, 0.1, 0.1, 0.3);
        }
        if (age % 3 != 0) return;

        Vec3 end = eye.add(look.scale(RANGE));
        BlockHitResult bhit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        double blockDistSqr = bhit.getType() == HitResult.Type.MISS ? Double.MAX_VALUE : bhit.getLocation().distanceToSqr(eye);
        AABB box = p.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
        EntityHitResult ehit = ProjectileUtil.getEntityHitResult(p, eye, end, box,
                e -> !e.isSpectator() && !(e instanceof Player) && e.isPickable(), RANGE * RANGE);
        if (ehit == null || ehit.getLocation().distanceToSqr(eye) > blockDistSqr) return;

        Entity target = ehit.getEntity();
        if (target instanceof PartEntity<?> part) target = part.getParent();
        if (target.isRemoved() || target instanceof Player || isDissolving(target)) return;

        Vec3 axis = new Vec3(right.x, 0, right.z).normalize();
        LIST.add(new Dissolve(target, axis));
        if (target instanceof Mob m) m.setNoAi(true);
        target.setNoGravity(true);
        target.setDeltaMovement(Vec3.ZERO);
        target.setInvulnerable(true);
        level.playSound(null, target.blockPosition(), SoundEvents.SOUL_ESCAPE, SoundSource.PLAYERS, 1.5f, 0.7f);
        level.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_CLUSTER_BREAK, SoundSource.PLAYERS, 1.0f, 0.5f);
    }

    @Override
    public void stop(ServerPlayer p) {
    }

    public static void tickAll() {
        Iterator<Dissolve> it = LIST.iterator();
        while (it.hasNext()) {
            Dissolve d = it.next();
            Entity e = d.entity;
            if (e.isRemoved() || !(e.level() instanceof ServerLevel level)) {
                it.remove();
                continue;
            }
            d.age++;
            float prog = d.age / (float) DURATION;
            e.setDeltaMovement(Vec3.ZERO);
            e.hurtMarked = true;

            AABB bb = e.getBoundingBox();
            Vec3 c = bb.getCenter();
            Vec3 ax = d.axis;
            double half = (Math.abs(ax.x) * bb.getXsize() + Math.abs(ax.z) * bb.getZsize()) / 2.0 + 0.05;
            double cp = c.dot(ax);
            double min = cp - half, max = cp + half;
            double thr = min + (max - min) * prog;
            double band = (max - min) * 0.4 + 0.15;

            RandomSource rnd = level.random;
            for (int i = 0; i < 70; i++) {
                double x = bb.minX + rnd.nextDouble() * bb.getXsize();
                double y = bb.minY + rnd.nextDouble() * bb.getYsize();
                double z = bb.minZ + rnd.nextDouble() * bb.getZsize();
                double proj = x * ax.x + z * ax.z;
                if (proj <= thr && proj >= thr - band) {
                    double sp = 0.07 + rnd.nextDouble() * 0.12;
                    level.sendParticles(ModParticles.VOID_ASH.get(), x, y, z, 0,
                            ax.x * sp + (rnd.nextDouble() - 0.5) * 0.03,
                            0.02 + rnd.nextDouble() * 0.04,
                            ax.z * sp + (rnd.nextDouble() - 0.5) * 0.03, 1.0);
                }
            }
            if (d.age % 4 == 0) {
                level.playSound(null, e.blockPosition(), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.25f, 2.0f);
            }
            if (prog >= 0.45f && e instanceof LivingEntity le && !le.isInvisible()) le.setInvisible(true);
            if (d.age >= DURATION) {
                level.sendParticles(ModParticles.VOID_ASH.get(), c.x, c.y, c.z, 0, ax.x * 0.1, 0.05, ax.z * 0.1, 1.0);
                level.playSound(null, e.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.6f, 0.6f);
                e.discard();
                it.remove();
            }
        }
    }
}
