package com.godhands.power;

import com.godhands.ModEntities;
import com.godhands.entity.SunEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Olhe para o Sol, segure o botão direito para puxá-lo; solte para lançá-lo. */
public class SunPower implements PowerLogic {
    private static final Map<UUID, SunEntity> SUNS = new HashMap<>();
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();
    private static final double START_DIST = 80.0;
    private static final double HOLD_DIST = 22.0;

    @Override
    public void start(ServerPlayer p) {
    }

    @Override
    public void tick(ServerPlayer p, int age) {
        UUID id = p.getUUID();
        ServerLevel level = p.serverLevel();
        SunEntity sun = SUNS.get(id);
        if (sun != null && sun.isRemoved()) {
            SUNS.remove(id);
            sun = null;
        }

        if (sun == null) {
            if (level.getGameTime() < COOLDOWN.getOrDefault(id, 0L)) {
                if (age % 20 == 1) Fx.msg(p, "msg.godhands.cooldown");
                return;
            }
            if (!level.dimensionType().hasSkyLight() || level.dimensionType().hasCeiling()) {
                if (age % 20 == 1) Fx.msg(p, "msg.godhands.no_sun");
                return;
            }
            float ang = level.getSunAngle(1.0f);
            Vec3 s = new Vec3(-Mth.sin(ang), Mth.cos(ang), 0);
            if (s.y < 0.08) {
                if (age % 20 == 1) Fx.msg(p, "msg.godhands.night");
                return;
            }
            if (p.getLookAngle().dot(s) < 0.975) {
                if (age % 20 == 1) Fx.msg(p, "msg.godhands.look_sun");
                return;
            }
            sun = new SunEntity(ModEntities.SUN.get(), level);
            sun.setPos(p.getEyePosition().add(s.scale(START_DIST)));
            sun.setSize(2.0f);
            sun.owner = id;
            level.addFreshEntity(sun);
            SUNS.put(id, sun);
            level.playSound(null, p.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 0.8f, 0.5f);
            level.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 0.5f);
            Fx.to(p, Fx.SHAKE, 30);
            return;
        }

        // puxa o sol até a frente do jogador
        Vec3 eye = p.getEyePosition();
        Vec3 target = eye.add(p.getLookAngle().scale(HOLD_DIST));
        Vec3 pos = sun.position();
        Vec3 diff = target.subtract(pos);
        double dist = diff.length();
        double speed = Math.max(0.25, dist * 0.025);
        if (dist > 0.01) sun.setPos(pos.add(diff.scale(Math.min(speed, dist) / dist)));
        double progress = Mth.clamp(1.0 - dist / START_DIST, 0.0, 1.0);
        sun.setSize((float) (2.0 + 4.0 * progress));

        if (age % 6 == 0 && progress > 0.4) Fx.to(p, Fx.SHAKE, 8);
        if (age % 25 == 0) {
            level.playSound(null, p.blockPosition(), SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 1.0f, 0.5f);
            level.playSound(null, p.blockPosition(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 1.0f, 0.5f);
        }
    }

    @Override
    public void stop(ServerPlayer p) {
        UUID id = p.getUUID();
        SunEntity sun = SUNS.remove(id);
        if (sun == null || sun.isRemoved()) return;
        ServerLevel level = p.serverLevel();
        sun.launch(p.getLookAngle().scale(3.0));
        COOLDOWN.put(id, level.getGameTime() + 200);
        level.playSound(null, p.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 2.0f, 0.5f);
        level.playSound(null, p.blockPosition(), SoundEvents.GHAST_SHOOT, SoundSource.PLAYERS, 2.0f, 0.5f);
        Fx.to(p, Fx.SHAKE, 15);
    }
}
