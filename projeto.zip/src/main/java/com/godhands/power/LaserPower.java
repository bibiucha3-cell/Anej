package com.godhands.power;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Laser pelos olhos: atravessa entidades, queima e derrete o que é frágil. */
public class LaserPower implements PowerLogic {
    private static final double RANGE = 64.0;
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(1.0f, 0.05f, 0.05f), 1.3f);
    private static final DustParticleOptions CORE = new DustParticleOptions(new Vector3f(1.0f, 0.85f, 0.85f), 0.8f);

    @Override
    public void start(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        level.playSound(null, p.blockPosition(), SoundEvents.WARDEN_SONIC_CHARGE, SoundSource.PLAYERS, 1.0f, 1.3f);
        level.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.6f, 0.7f);
    }

    @Override
    public void tick(ServerPlayer p, int age) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(RANGE));
        BlockHitResult bh = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        boolean hitBlock = bh.getType() == HitResult.Type.BLOCK;
        Vec3 hit = hitBlock ? bh.getLocation() : end;
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();

        // um raio de cada olho, convergindo no alvo
        for (int side = -1; side <= 1; side += 2) {
            Vec3 origin = eye.add(look.scale(0.35)).add(right.scale(0.14 * side)).add(0, 0.02, 0);
            Vec3 d = hit.subtract(origin);
            double len = d.length();
            if (len < 0.5) continue;
            Vec3 dir = d.scale(1.0 / len);
            for (double t = 0; t < len; t += 1.1) {
                Vec3 q = origin.add(dir.scale(t));
                level.sendParticles(RED, q.x, q.y, q.z, 1, 0.03, 0.03, 0.03, 0.0);
                if (((int) (t * 10) & 1) == 0) level.sendParticles(CORE, q.x, q.y, q.z, 1, 0, 0, 0, 0.0);
            }
        }

        // dano em tudo no caminho
        if (age % 4 == 0) {
            AABB box = new AABB(eye, hit).inflate(1.5);
            for (Entity e : level.getEntities(p, box, x -> x instanceof LivingEntity && !x.isSpectator())) {
                if (e.getBoundingBox().inflate(0.3).clip(eye, hit).isPresent()) {
                    e.hurt(level.damageSources().playerAttack(p), 5.0f);
                    e.setSecondsOnFire(5);
                    Vec3 c = e.getBoundingBox().getCenter();
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 6, 0.3, 0.3, 0.3, 0.2);
                }
            }
        }

        if (hitBlock) {
            BlockPos pos = bh.getBlockPos();
            BlockState st = level.getBlockState(pos);
            level.sendParticles(ParticleTypes.FLAME, hit.x, hit.y, hit.z, 3, 0.15, 0.15, 0.15, 0.04);
            level.sendParticles(ParticleTypes.SMOKE, hit.x, hit.y, hit.z, 2, 0.15, 0.15, 0.15, 0.02);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, hit.x, hit.y, hit.z, 2, 0.2, 0.2, 0.2, 0.15);
            if (age % 2 == 0) level.sendParticles(ParticleTypes.LAVA, hit.x, hit.y, hit.z, 1, 0.1, 0.1, 0.1, 0.0);
            if (!st.isAir()) {
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), hit.x, hit.y, hit.z, 3, 0.15, 0.15, 0.15, 0.05);
            }
            if (age % 8 == 0) {
                BlockPos fp = pos.relative(bh.getDirection());
                if (level.isEmptyBlock(fp) && BaseFireBlock.canBePlacedAt(level, fp, bh.getDirection())) {
                    level.setBlockAndUpdate(fp, BaseFireBlock.getState(level, fp));
                }
            }
            float hard = st.getDestroySpeed(level, pos);
            if (age % 3 == 0 && !st.isAir() && hard >= 0 && hard <= 0.3f && level.getBlockEntity(pos) == null) {
                level.destroyBlock(pos, false);
            }
        }

        if (age % 5 == 0) {
            level.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.3f, 0.5f);
            if (hitBlock) level.playSound(null, BlockPos.containing(hit.x, hit.y, hit.z), SoundEvents.FIRE_AMBIENT,
                    SoundSource.PLAYERS, 0.7f, 1.2f);
        }
    }

    @Override
    public void stop(ServerPlayer p) {
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.8f, 1.4f);
    }
}
