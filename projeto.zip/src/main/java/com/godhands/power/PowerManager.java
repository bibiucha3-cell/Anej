package com.godhands.power;

import com.godhands.GodHandsMod;
import com.godhands.item.GodHandsItem;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Liga o botão direito segurado ao poder selecionado. */
@Mod.EventBusSubscriber(modid = GodHandsMod.MODID)
public class PowerManager {
    private static final Map<Power, PowerLogic> LOGIC = new EnumMap<>(Power.class);
    private static final Map<UUID, Active> ACTIVE = new HashMap<>();

    static {
        LOGIC.put(Power.TELEKINESIS, new TelekinesisPower());
        LOGIC.put(Power.SUPERSPEED, new SuperSpeedPower());
        LOGIC.put(Power.LASER, new LaserPower());
        LOGIC.put(Power.SUN, new SunPower());
        LOGIC.put(Power.VOID, new VoidPower());
        LOGIC.put(Power.TIME, new TimePower());
        LOGIC.put(Power.REALITY, new RealityPower());
    }

    private static class Active {
        final Power power;
        int age = 0;
        Active(Power power) { this.power = power; }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        Power want = player.isSpectator() ? Power.NONE : GodHandsItem.usingPower(player);
        Active a = ACTIVE.get(player.getUUID());
        if (a != null && a.power != want) {
            stop(player);
            a = null;
        }
        if (want != Power.NONE) {
            PowerLogic logic = LOGIC.get(want);
            if (a == null) {
                a = new Active(want);
                ACTIVE.put(player.getUUID(), a);
                logic.start(player);
            }
            a.age++;
            logic.tick(player, a.age);
        }
        TimePower.recordTick(player);
    }

    public static void stop(ServerPlayer player) {
        Active a = ACTIVE.remove(player.getUUID());
        if (a != null) LOGIC.get(a.power).stop(player);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        TelekinesisPower.tickThrown();
        VoidPower.tickAll();
        RealityPower.tickWaves();
    }

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        if (SuperSpeedPower.shouldSkip(event.getEntity()) && event.isCancelable()) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            stop(sp);
            if (TimePower.tryRevive(sp)) event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            stop(sp);
            TimePower.clear(sp);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) stop(sp);
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        ACTIVE.clear();
    }
}
