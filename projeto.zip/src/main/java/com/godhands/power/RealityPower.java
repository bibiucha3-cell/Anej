package com.godhands.power;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Olhe para o chão e use: os blocos ao redor viram outra "realidade" (outro bioma), em uma onda. */
public class RealityPower implements PowerLogic {
    private record Theme(BlockState stone, BlockState stone2, BlockState surface, BlockState sub,
                         BlockState sand, BlockState log, BlockState leaves, BlockState water) {}

    private static BlockState b(Block block) {
        return block.defaultBlockState();
    }

    private static final List<Theme> THEMES = List.of(
            // Nether
            new Theme(b(Blocks.NETHERRACK), b(Blocks.BLACKSTONE), b(Blocks.CRIMSON_NYLIUM), b(Blocks.NETHERRACK),
                    b(Blocks.SOUL_SAND), b(Blocks.CRIMSON_STEM), b(Blocks.NETHER_WART_BLOCK), b(Blocks.MAGMA_BLOCK)),
            // End
            new Theme(b(Blocks.END_STONE), b(Blocks.END_STONE_BRICKS), b(Blocks.END_STONE), b(Blocks.END_STONE),
                    b(Blocks.END_STONE), b(Blocks.PURPUR_PILLAR), b(Blocks.AMETHYST_BLOCK), b(Blocks.AIR)),
            // Deserto
            new Theme(b(Blocks.SANDSTONE), b(Blocks.SMOOTH_SANDSTONE), b(Blocks.SAND), b(Blocks.SANDSTONE),
                    b(Blocks.SAND), b(Blocks.ACACIA_LOG), b(Blocks.ACACIA_LEAVES), b(Blocks.SAND)),
            // Gelo
            new Theme(b(Blocks.PACKED_ICE), b(Blocks.BLUE_ICE), b(Blocks.SNOW_BLOCK), b(Blocks.SNOW_BLOCK),
                    b(Blocks.SNOW_BLOCK), b(Blocks.SPRUCE_LOG), b(Blocks.SPRUCE_LEAVES), b(Blocks.ICE)),
            // Cogumelo
            new Theme(b(Blocks.SMOOTH_STONE), b(Blocks.CALCITE), b(Blocks.MYCELIUM), b(Blocks.DIRT),
                    b(Blocks.PODZOL), b(Blocks.MUSHROOM_STEM), b(Blocks.RED_MUSHROOM_BLOCK), null),
            // Mesa
            new Theme(b(Blocks.TERRACOTTA), b(Blocks.ORANGE_TERRACOTTA), b(Blocks.RED_SAND), b(Blocks.RED_SANDSTONE),
                    b(Blocks.RED_SAND), b(Blocks.DARK_OAK_LOG), b(Blocks.DARK_OAK_LEAVES), null),
            // Sombrio
            new Theme(b(Blocks.DEEPSLATE), b(Blocks.COBBLED_DEEPSLATE), b(Blocks.SCULK), b(Blocks.DEEPSLATE),
                    b(Blocks.SCULK), b(Blocks.WARPED_STEM), b(Blocks.WARPED_WART_BLOCK), null)
    );

    private static class Wave {
        final ServerLevel level;
        final BlockPos center;
        final Theme theme;
        int r = 0;
        static final int MAX = 12;

        Wave(ServerLevel level, BlockPos center, Theme theme) {
            this.level = level;
            this.center = center;
            this.theme = theme;
        }
    }

    private static final List<Wave> WAVES = new ArrayList<>();
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();
    private static int lastTheme = -1;

    @Override
    public void start(ServerPlayer p) {
    }

    @Override
    public void tick(ServerPlayer p, int age) {
        if (age != 1 && age % 20 != 1) return; // tenta ao começar e depois 1x por segundo
        ServerLevel level = p.serverLevel();
        UUID id = p.getUUID();
        if (level.getGameTime() < COOLDOWN.getOrDefault(id, 0L)) {
            Fx.msg(p, "msg.godhands.cooldown");
            return;
        }
        Vec3 eye = p.getEyePosition();
        BlockHitResult bh = level.clip(new ClipContext(eye, eye.add(p.getLookAngle().scale(14)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (bh.getType() != HitResult.Type.BLOCK || p.getXRot() < 15f) {
            Fx.msg(p, "msg.godhands.look_ground");
            return;
        }
        int idx;
        do {
            idx = level.random.nextInt(THEMES.size());
        } while (idx == lastTheme);
        lastTheme = idx;

        BlockPos c = bh.getBlockPos();
        WAVES.add(new Wave(level, c, THEMES.get(idx)));
        COOLDOWN.put(id, level.getGameTime() + 100);

        level.playSound(null, c, SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 0.5f, 1.6f);
        level.playSound(null, c, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 0.6f);
        level.playSound(null, c, SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 0.7f);
        Fx.near(level, Vec3.atCenterOf(c), 48, Fx.REALITY, 0);
        Fx.near(level, Vec3.atCenterOf(c), 48, Fx.SHAKE, 20);
    }

    @Override
    public void stop(ServerPlayer p) {
    }

    public static void tickWaves() {
        Iterator<Wave> it = WAVES.iterator();
        while (it.hasNext()) {
            Wave w = it.next();
            w.r++;
            int r = w.r;
            ServerLevel level = w.level;
            RandomSource rnd = level.random;
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                        if (dist >= r || dist < r - 1) continue;
                        pos.set(w.center.getX() + dx, w.center.getY() + dy, w.center.getZ() + dz);
                        if (!level.isInWorldBounds(pos) || !level.isLoaded(pos)) continue;
                        BlockState old = level.getBlockState(pos);
                        BlockState ns = transform(level, pos, old, w.theme, rnd);
                        if (ns != null && ns != old) {
                            level.setBlock(pos, ns, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
                        }
                    }
                }
            }
            // efeitos na borda da onda
            for (int i = 0; i < 30; i++) {
                double th = rnd.nextDouble() * Math.PI * 2;
                double ph = Math.acos(2 * rnd.nextDouble() - 1);
                double x = w.center.getX() + 0.5 + r * Math.sin(ph) * Math.cos(th);
                double y = w.center.getY() + 0.5 + r * Math.cos(ph);
                double z = w.center.getZ() + 0.5 + r * Math.sin(ph) * Math.sin(th);
                level.sendParticles(rnd.nextBoolean() ? ParticleTypes.PORTAL : ParticleTypes.END_ROD, x, y, z, 1, 0.2, 0.2, 0.2, 0.1);
            }
            if (r % 2 == 0) {
                level.playSound(null, w.center, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.2f, 0.6f + r * 0.08f);
            }
            if (r >= Wave.MAX) {
                level.playSound(null, w.center, SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 1.4f);
                it.remove();
            }
        }
    }

    private static BlockState transform(ServerLevel level, BlockPos pos, BlockState s, Theme t, RandomSource rnd) {
        if (s.isAir() || s.hasBlockEntity() || s.getDestroySpeed(level, pos) < 0) return null;
        if (s.is(Blocks.WATER)) return t.water();
        if (!s.getFluidState().isEmpty()) return null;
        if (s.is(BlockTags.LOGS)) {
            BlockState ns = t.log();
            if (s.hasProperty(RotatedPillarBlock.AXIS) && ns.hasProperty(RotatedPillarBlock.AXIS)) {
                ns = ns.setValue(RotatedPillarBlock.AXIS, s.getValue(RotatedPillarBlock.AXIS));
            }
            return ns;
        }
        if (s.is(BlockTags.LEAVES)) {
            BlockState ns = t.leaves();
            if (ns.hasProperty(LeavesBlock.PERSISTENT)) ns = ns.setValue(LeavesBlock.PERSISTENT, true);
            return ns;
        }
        if (s.is(BlockTags.DIRT)) {
            return level.getBlockState(pos.above()).isAir() ? t.surface() : t.sub();
        }
        if (s.is(BlockTags.SAND)) return t.sand();
        if (s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.BASE_STONE_NETHER) || s.is(Blocks.GRAVEL)) {
            return rnd.nextFloat() < 0.2f ? t.stone2() : t.stone();
        }
        if (s.getBlock() instanceof BushBlock) return Blocks.AIR.defaultBlockState();
        return null;
    }
}
