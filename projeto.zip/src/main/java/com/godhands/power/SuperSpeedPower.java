package com.godhands.power;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** "Supervelocidade": o mundo fica em câmera lenta e o jogador segue na velocidade normal. */
public class SuperSpeedPower implements PowerLogic {
    private static final Map<UUID, ServerPlayer> OWNERS = new HashMap<>();
    private static final double RADIUS = 48.0;
    private static final DustParticleOptions ORANGE = new DustParticleOptions(new Vector3f(1.0f, 0.55f, 0.15f), 1.6f);

    @Override
    public void start(ServerPlayer p) {
        OWNERS.put(p.getUUID(), p);
        Fx.to(p, Fx.SLOW_ON, 0);
        ServerLevel level = p.serverLevel();
        level.playSound(null, p.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.2f, 0.5f);
        level.playSound(null, p.blockPosition(), SoundEvents.PORTAL_TRIGGER, SoundSource.PLAYERS, 0.5f, 0.6f);
    }

    @Override
    public void tick(ServerPlayer p, int age) {
        ServerLevel level = p.serverLevel();
        OWNERS.put(p.getUUID(), p);

        // onda de partículas laranja expandindo
        if (age <= 20) {
            double r = age * 2.0;
            for (int i = 0; i < 48; i++) {
                double a = i * Math.PI * 2 / 48;
                level.sendParticles(ORANGE, p.getX() + Math.cos(a) * r, p.getY() + 0.3, p.getZ() + Math.sin(a) * r,
                        1, 0.0, 0.2, 0.0, 0.0);
            }
        }
        if (age % 20 == 0) {
            level.playSound(null, p.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.PLAYERS, 0.9f, 0.6f);
        }
        // projéteis, itens, TNT e blocos caindo: perdem velocidade rápido
        for (Entity e : level.getEntitiesOfClass(Entity.class, p.getBoundingBox().inflate(RADIUS),
                x -> x instanceof Projectile || x instanceof ItemEntity || x instanceof PrimedTnt
                        || (x instanceof FallingBlockEntity && !TelekinesisPower.isHeld(x)))) {
            if (e.getDeltaMovement().lengthSqr() > 0.0004) {
                e.setDeltaMovement(e.getDeltaMovement().scale(0.8));
                e.hurtMarked = true;
            }
        }
    }

    @Override
    public void stop(ServerPlayer p) {
        OWNERS.remove(p.getUUID());
        Fx.to(p, Fx.SLOW_OFF, 0);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.8f, 1.6f);
    }

    /** Chamado todo tick de entidade viva: pula 3 de cada 4 ticks perto de quem usa o poder. */
    public static boolean shouldSkip(LivingEntity le) {
        if (OWNERS.isEmpty() || le.level().isClientSide || le instanceof Player) return false;
        if (le.tickCount % 4 == 0) return false;
        for (ServerPlayer sp : OWNERS.values()) {
            if (sp.level() == le.level() && sp.distanceToSqr(le) < RADIUS * RADIUS) return true;
        }
        return false;
    }
}
