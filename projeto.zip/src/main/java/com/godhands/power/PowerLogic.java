package com.godhands.power;

import net.minecraft.server.level.ServerPlayer;

public interface PowerLogic {
    void start(ServerPlayer player);
    void tick(ServerPlayer player, int age);
    void stop(ServerPlayer player);
}
