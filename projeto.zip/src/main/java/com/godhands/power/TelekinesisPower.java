package com.godhands.power;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.PartEntity;

import java.util.*;

/** Telecinese com física: mola + inércia, blocos tremem antes de soltar do chão e quebram ao bater forte. */
public class TelekinesisPower implements PowerLogic {
    private static final Map<UUID, Grab> GRABS = new HashMap<>();
    private static final List<Thrown> THROWN = new ArrayList<>();
    private static final double REACH = 28.0;
    private static final double MIN_DIST = 2.5;

    private static class Grab {
        final Entity entity;
        final BlockState state;
        double distance;
        final boolean wasNoGravity, wasGlowing;
        int age = 0;

        Grab(Entity entity, BlockState state, double distance) {
            this.entity = entity;
            this.state = state;
            this.distance = distance;
            this.wasNoGravity = entity.isNoGravity();
            this.wasGlowing = entity.hasGlowingTag();
        }
    }

    private static class Thrown {
        final Entity entity;
        final BlockState state;
        double lastSpeed;
        Vec3 lastPos;
        int age = 0;

        Thrown(Entity entity, BlockState state) {
            this.entity = entity;
            this.state = state;
            this.lastPos = entity.position();
        }
    }

    public static boolean isHeld(Entity e) {
        for (Grab g : GRABS.values()) if (g.entity == e) return true;
        return false;
    }

    @Override
    public void start(ServerPlayer player) {
    }

    @Override
    public void tick(ServerPlayer player, int age) {
        Grab g = GRABS.get(player.getUUID());
        if (g == null) {
            if (age % 2 == 0) tryGrab(player);
        } else {
            update(player, g);
        }
    }

    @Override
    public void stop(ServerPlayer player) {
        release(player);
    }

    private static boolean grabbedByOther(Entity e, ServerPlayer self) {
        for (Map.Entry<UUID, Grab> en : GRABS.entrySet()) {
            if (!en.getKey().equals(self.getUUID()) && en.getValue().entity == e) return true;
        }
        return false;
    }

    private static void tryGrab(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = eye.add(look.scale(REACH));

        BlockHitResult bhit = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE,
                ClipContext.Fluid.NONE, player));
        double blockDistSqr = bhit.getType() == HitResult.Type.MISS
                ? Double.MAX_VALUE : bhit.getLocation().distanceToSqr(eye);

        AABB box = player.getBoundingBox().expandTowards(look.scale(REACH)).inflate(1.0);
        EntityHitResult ehit = ProjectileUtil.getEntityHitResult(player, eye, end, box,
                e -> !e.isSpectator() && !(e instanceof Player) && (e.isPickable() || e instanceof ItemEntity),
                REACH * REACH);

        if (ehit != null && ehit.getLocation().distanceToSqr(eye) < blockDistSqr) {
            Entity target = ehit.getEntity();
            if (target instanceof PartEntity<?> part) target = part.getParent();
            if (!grabbedByOther(target, player)) {
                double d = Mth.clamp(ehit.getLocation().distanceTo(eye), MIN_DIST, REACH);
                start(player, target, null, d);
                return;
            }
        }

        if (bhit.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = bhit.getBlockPos();
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || state.getDestroySpeed(level, pos) < 0 || level.getBlockEntity(pos) != null) return;
            double d = Mth.clamp(Math.sqrt(blockDistSqr), MIN_DIST, REACH);
            FallingBlockEntity block = FallingBlockEntity.fall(level, pos, state);
            block.time = 1;
            start(player, block, state, d);
        }
    }

    private static void start(ServerPlayer player, Entity target, BlockState state, double distance) {
        Grab grab = new Grab(target, state, distance);
        GRABS.put(player.getUUID(), grab);
        target.setNoGravity(true);
        target.setGlowingTag(true);
        target.fallDistance = 0;

        ServerLevel level = player.serverLevel();
        Vec3 c = target.getBoundingBox().getCenter();
        level.playSound(null, player.blockPosition(), SoundEvents.ILLUSIONER_CAST_SPELL, SoundSource.PLAYERS, 0.9f, 1.4f);
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.6f, 1.8f);
        level.playSound(null, target.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0f, 1.2f);
        level.sendParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 30, 0.4, 0.4, 0.4, 0.3);
        if (state != null) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), c.x, c.y - 0.4, c.z,
                    25, 0.4, 0.2, 0.4, 0.05);
        }
    }

    private static void update(ServerPlayer player, Grab g) {
        Entity e = g.entity;
        if (e.isRemoved() || e.level() != player.level()) {
            GRABS.remove(player.getUUID());
            return;
        }
        ServerLevel level = player.serverLevel();
        g.age++;
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 center = e.getBoundingBox().getCenter();

        // bloco: treme no chão antes de se soltar
        if (g.state != null && g.age < 8) {
            RandomJitter.apply(e, level);
            if (g.age % 2 == 0) {
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, g.state),
                        center.x, center.y - 0.5, center.z, 5, 0.35, 0.05, 0.35, 0.03);
                level.playSound(null, e.blockPosition(), g.state.getSoundType().getBreakSound(),
                        SoundSource.BLOCKS, 0.6f, 0.6f);
            }
            beam(level, player, g, eye, look, center);
            return;
        }

        Vec3 target = eye.add(look.scale(g.distance)).add(0, Math.sin(g.age * 0.12) * 0.06, 0);
        Vec3 diff = target.subtract(center);
        Vec3 v = e.getDeltaMovement().scale(0.80).add(diff.scale(0.07));
        if (v.lengthSqr() > 2.56) v = v.normalize().scale(1.6);
        e.setDeltaMovement(v);
        e.fallDistance = 0;
        if (e instanceof FallingBlockEntity fb) {
            fb.time = 1;
        } else {
            e.hurtMarked = true;
            if (e instanceof Mob mob) mob.getNavigation().stop();
        }
        if (g.state != null && v.lengthSqr() > 0.12 && g.age % 2 == 0) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, g.state),
                    center.x, center.y - 0.4, center.z, 2, 0.2, 0.2, 0.2, 0.02);
        }
        beam(level, player, g, eye, look, e.getBoundingBox().getCenter());
    }

    private static void beam(ServerLevel level, ServerPlayer player, Grab g, Vec3 eye, Vec3 look, Vec3 center) {
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        Vec3 hand = eye.add(look.scale(0.8)).add(right.scale(0.35)).add(0, -0.3, 0);
        Entity e = g.entity;
        if (g.age % 2 == 0) {
            Vec3 d = center.subtract(hand);
            double len = d.length();
            if (len > 0.1) {
                Vec3 dir = d.scale(1.0 / len);
                for (double t = 0; t < len; t += 1.0) {
                    Vec3 p = hand.add(dir.scale(t));
                    level.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.03, 0.03, 0.03, 0.0);
                }
                if (g.age % 4 == 0) {
                    Vec3 p = hand.add(dir.scale(len * level.random.nextDouble()));
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 2, 0.1, 0.1, 0.1, 0.1);
                }
            }
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, hand.x, hand.y, hand.z, 2, 0.08, 0.08, 0.08, 0.05);
        }
        double radius = Math.max(e.getBbWidth(), 0.6) * 0.8 + 0.3;
        double ang = g.age * 0.35;
        for (int i = 0; i < 3; i++) {
            double a = ang + i * Math.PI * 2 / 3;
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    center.x + Math.cos(a) * radius,
                    center.y + Math.sin(g.age * 0.1 + i) * 0.3,
                    center.z + Math.sin(a) * radius, 1, 0, 0, 0, 0);
        }
        if (g.age % 25 == 0) {
            level.playSound(null, e.blockPosition(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 0.25f, 1.9f);
        }
    }

    private static class RandomJitter {
        static void apply(Entity e, ServerLevel level) {
            e.setDeltaMovement((level.random.nextDouble() - 0.5) * 0.05, 0.0, (level.random.nextDouble() - 0.5) * 0.05);
            if (e instanceof FallingBlockEntity fb) fb.time = 1;
        }
    }

    public static void adjustDistance(ServerPlayer player, float delta) {
        Grab g = GRABS.get(player.getUUID());
        if (g == null) return;
        g.distance = Mth.clamp(g.distance + delta * 1.2, MIN_DIST, REACH);
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                SoundSource.PLAYERS, 0.3f, 1.2f + (float) (g.distance / REACH));
    }

    public static void release(ServerPlayer player) {
        Grab g = GRABS.remove(player.getUUID());
        if (g == null) return;
        Entity e = g.entity;
        ServerLevel level = player.serverLevel();
        if (!e.isRemoved()) {
            e.setNoGravity(g.wasNoGravity);
            e.setGlowingTag(g.wasGlowing);
            Vec3 v = e.getDeltaMovement().scale(1.3).add(player.getLookAngle().scale(0.4));
            e.setDeltaMovement(v);
            e.hurtMarked = true;
            e.fallDistance = 0;
            if (e instanceof FallingBlockEntity fb) {
                fb.time = 1;
                THROWN.add(new Thrown(e, g.state));
            }
            Vec3 c = e.getBoundingBox().getCenter();
            level.sendParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 25, 0.3, 0.3, 0.3, 0.15);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 20, 0.4, 0.4, 0.4, 0.25);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.6f, 1.7f);
        level.playSound(null, player.blockPosition(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.PLAYERS, 0.8f, 1.3f);
    }

    /** Blocos arremessados: quebram ao bater forte. */
    public static void tickThrown() {
        Iterator<Thrown> it = THROWN.iterator();
        while (it.hasNext()) {
            Thrown t = it.next();
            Entity e = t.entity;
            if (!(e.level() instanceof ServerLevel sl)) {
                it.remove();
                continue;
            }
            if (e.isRemoved()) {
                if (t.lastSpeed > 0.9) {
                    BlockPos bp = BlockPos.containing(t.lastPos.x, t.lastPos.y, t.lastPos.z);
                    impact(sl, t, t.lastPos);
                    for (BlockPos p : new BlockPos[]{bp, bp.below()}) {
                        if (t.lastSpeed > 1.1 && sl.getBlockState(p).is(t.state.getBlock())) {
                            sl.destroyBlock(p, true);
                            break;
                        }
                    }
                }
                it.remove();
                continue;
            }
            boolean hit = e.horizontalCollision || e.verticalCollision;
            if (hit && t.lastSpeed > 0.8) {
                impact(sl, t, e.position());
                e.spawnAtLocation(t.state.getBlock());
                e.discard();
                it.remove();
                continue;
            }
            t.lastSpeed = e.getDeltaMovement().length();
            t.lastPos = e.position();
            if (++t.age > 120 || e.onGround()) it.remove();
        }
    }

    private static void impact(ServerLevel sl, Thrown t, Vec3 pos) {
        sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, t.state), pos.x, pos.y + 0.4, pos.z,
                45, 0.4, 0.4, 0.4, 0.15);
        sl.sendParticles(ParticleTypes.POOF, pos.x, pos.y + 0.4, pos.z, 8, 0.3, 0.3, 0.3, 0.05);
        sl.playSound(null, BlockPos.containing(pos.x, pos.y, pos.z), t.state.getSoundType().getBreakSound(),
                SoundSource.BLOCKS, 1.4f, 0.7f);
    }
}
