package com.godhands.power;

import com.godhands.item.GodHandsItem;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.*;

/**
 * Manipulação do tempo: segurar = volta no tempo (jogador, mobs próximos e o relógio do mundo).
 * Passivo: se tiver o item no inventário e morrer, volta ~8 segundos no tempo (recarga de 30 s).
 */
public class TimePower implements PowerLogic {
    private record Snap(ResourceKey<Level> dim, double x, double y, double z, float yRot, float xRot, float health, int food) {}
    private record ESnap(double x, double y, double z, float yRot, float health) {}

    private static final int MAX_SNAPS = 80; // gravado a cada 2 ticks = 8 s
    private static final Map<UUID, ArrayDeque<Snap>> HIST = new HashMap<>();
    private static final Map<UUID, Map<UUID, ArrayDeque<ESnap>>> EHIST = new HashMap<>();
    private static final Map<UUID, Long> REVIVE_CD = new HashMap<>();
    private static final Set<UUID> REWINDING = new HashSet<>();
    private static final DustParticleOptions CYAN = new DustParticleOptions(new Vector3f(0.3f, 0.85f, 1.0f), 1.3f);

    /** Chamado todo tick de cada jogador. */
    public static void recordTick(ServerPlayer p) {
        if (p.tickCount % 2 != 0) return;
        UUID id = p.getUUID();
        if (!GodHandsItem.hasInInventory(p)) {
            HIST.remove(id);
            EHIST.remove(id);
            return;
        }
        if (REWINDING.contains(id) || !p.isAlive()) return;
        ArrayDeque<Snap> h = HIST.computeIfAbsent(id, k -> new ArrayDeque<>());
        h.addLast(new Snap(p.level().dimension(), p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot(),
                p.getHealth(), p.getFoodData().getFoodLevel()));
        while (h.size() > MAX_SNAPS) h.pollFirst();

        if (GodHandsItem.isHolding(p, Power.TIME)) {
            Map<UUID, ArrayDeque<ESnap>> em = EHIST.computeIfAbsent(id, k -> new HashMap<>());
            int count = 0;
            for (LivingEntity e : p.serverLevel().getEntitiesOfClass(LivingEntity.class,
                    p.getBoundingBox().inflate(32), x -> !(x instanceof Player) && x.isAlive())) {
                if (++count > 60) break;
                ArrayDeque<ESnap> q = em.computeIfAbsent(e.getUUID(), k -> new ArrayDeque<>());
                q.addLast(new ESnap(e.getX(), e.getY(), e.getZ(), e.getYRot(), e.getHealth()));
                while (q.size() > MAX_SNAPS) q.pollFirst();
            }
        }
    }

    public static void clear(ServerPlayer p) {
        HIST.remove(p.getUUID());
        EHIST.remove(p.getUUID());
        REWINDING.remove(p.getUUID());
        REVIVE_CD.remove(p.getUUID());
    }

    @Override
    public void start(ServerPlayer p) {
        REWINDING.add(p.getUUID());
        Fx.to(p, Fx.REWIND_ON, 0);
        ServerLevel level = p.serverLevel();
        level.playSound(null, p.blockPosition(), SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.35f, 2.0f);
        level.playSound(null, p.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.8f, 1.8f);
    }

    @Override
    public void tick(ServerPlayer p, int age) {
        UUID id = p.getUUID();
        ServerLevel level = p.serverLevel();
        ArrayDeque<Snap> h = HIST.get(id);

        // efeitos
        double a = age * 0.6;
        for (int i = 0; i < 3; i++) {
            double ang = a + i * Math.PI * 2 / 3;
            level.sendParticles(CYAN, p.getX() + Math.cos(ang) * 0.9, p.getY() + 0.1 + (age % 20) * 0.1,
                    p.getZ() + Math.sin(ang) * 0.9, 1, 0, 0, 0, 0);
        }
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 4, 0.5, 0.8, 0.5, 0.05);
        if (age % 2 == 0) {
            level.playSound(null, p.blockPosition(), SoundEvents.COMPARATOR_CLICK, SoundSource.PLAYERS, 0.5f,
                    1.2f + Math.min(0.8f, age * 0.01f));
        }

        if (h == null || h.isEmpty()) return;
        Snap s = h.pollLast();
        if (s.dim() != level.dimension()) {
            h.clear();
            return;
        }
        p.connection.teleport(s.x(), s.y(), s.z(), s.yRot(), s.xRot());
        p.setDeltaMovement(Vec3.ZERO);
        p.fallDistance = 0;
        p.clearFire();
        p.setHealth(Math.min(p.getMaxHealth(), Math.max(1.0f, s.health())));
        p.getFoodData().setFoodLevel(s.food());

        Map<UUID, ArrayDeque<ESnap>> em = EHIST.get(id);
        if (em != null) {
            for (Map.Entry<UUID, ArrayDeque<ESnap>> en : em.entrySet()) {
                Entity e = level.getEntity(en.getKey());
                if (e instanceof LivingEntity le && le.isAlive()) {
                    ESnap es = en.getValue().pollLast();
                    if (es != null) {
                        le.moveTo(es.x(), es.y(), es.z(), es.yRot(), 0.0f);
                        le.setDeltaMovement(Vec3.ZERO);
                        le.fallDistance = 0;
                        le.hurtMarked = true;
                        le.setHealth(Math.min(le.getMaxHealth(), es.health()));
                    }
                }
            }
        }
        level.setDayTime(Math.max(0L, level.getDayTime() - 30L));
    }

    @Override
    public void stop(ServerPlayer p) {
        REWINDING.remove(p.getUUID());
        Fx.to(p, Fx.REWIND_OFF, 0);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0f, 0.8f);
    }

    /** Morte evitada: volta ~8 s no tempo. Funciona com o item em qualquer lugar do inventário. */
    public static boolean tryRevive(ServerPlayer p) {
        if (!GodHandsItem.hasInInventory(p)) return false;
        UUID id = p.getUUID();
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        if (now < REVIVE_CD.getOrDefault(id, 0L)) return false;
        ArrayDeque<Snap> h = HIST.get(id);
        if (h == null || h.isEmpty()) return false;

        Snap s = h.peekFirst();
        h.clear();
        ServerLevel target = p.server.getLevel(s.dim());
        if (target == null) target = level;
        p.teleportTo(target, s.x(), s.y(), s.z(), s.yRot(), s.xRot());
        p.setHealth(Math.max(8.0f, Math.min(p.getMaxHealth(), s.health())));
        p.getFoodData().setFoodLevel(Math.max(10, s.food()));
        p.clearFire();
        p.fallDistance = 0;
        p.setDeltaMovement(Vec3.ZERO);
        p.removeAllEffects();
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 3));
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
        p.setAirSupply(p.getMaxAirSupply());
        REVIVE_CD.put(id, now + 600L);

        ServerLevel tl = p.serverLevel();
        tl.playSound(null, p.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 1.0f, 1.0f);
        tl.playSound(null, p.blockPosition(), SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.6f, 2.0f);
        tl.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 80, 0.6, 1.0, 0.6, 0.2);
        tl.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.5, 1.0, 0.5, 0.15);
        Fx.to(p, Fx.REWIND_PULSE, 0);
        Fx.msg(p, "msg.godhands.revived");
        return true;
    }
}
