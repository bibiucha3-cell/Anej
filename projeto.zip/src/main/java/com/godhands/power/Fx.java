package com.godhands.power;

import com.godhands.network.FxPacket;
import com.godhands.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

public class Fx {
    public static final int SLOW_ON = 0, SLOW_OFF = 1, FLASH = 2, REWIND_ON = 3, REWIND_OFF = 4,
            REALITY = 5, SHAKE = 6, SHAKE_BIG = 7, REWIND_PULSE = 8;

    public static void to(ServerPlayer p, int type, int arg) {
        ModNetwork.CH.send(PacketDistributor.PLAYER.with(() -> p), new FxPacket(type, arg));
    }

    public static void near(ServerLevel level, Vec3 pos, double radius, int type, int arg) {
        ModNetwork.CH.send(PacketDistributor.NEAR.with(
                () -> new PacketDistributor.TargetPoint(pos.x, pos.y, pos.z, radius, level.dimension())),
                new FxPacket(type, arg));
    }

    public static void msg(ServerPlayer p, String key) {
        p.displayClientMessage(Component.translatable(key).withStyle(ChatFormatting.GOLD), true);
    }
}
