package com.godhands.power;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/** A ordem aqui é a ordem na roda. */
public enum Power {
    NONE("none", Items.BARRIER, 0xFF6B6B),
    TELEKINESIS("telekinesis", Items.ENDER_EYE, 0x5CE1FF),
    SUPERSPEED("superspeed", Items.RABBIT_FOOT, 0xFF9B3D),
    LASER("laser", Items.REDSTONE, 0xFF3030),
    SUN("sun", Items.SUNFLOWER, 0xFFD43B),
    VOID("void", Items.OBSIDIAN, 0xA070FF),
    TIME("time", Items.CLOCK, 0x4DD2FF),
    REALITY("reality", Items.END_CRYSTAL, 0xFF6BDF);

    public final String key;
    public final Item icon;
    public final int color;

    Power(String key, Item icon, int color) {
        this.key = key;
        this.icon = icon;
        this.color = color;
    }

    public static Power byId(int id) {
        Power[] v = values();
        return id >= 0 && id < v.length ? v[id] : NONE;
    }
}
