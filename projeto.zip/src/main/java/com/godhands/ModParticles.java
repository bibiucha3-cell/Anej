package com.godhands;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, GodHandsMod.MODID);

    public static final RegistryObject<SimpleParticleType> VOID_ASH =
            PARTICLES.register("void_ash", () -> new SimpleParticleType(true));
}
