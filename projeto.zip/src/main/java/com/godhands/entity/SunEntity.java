package com.godhands.entity;

import com.godhands.power.Fx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/** O Sol puxado pelo jogador. Quando solto, voa e causa uma mega explosão. */
public class SunEntity extends Entity {
    private static final EntityDataAccessor<Float> SIZE = SynchedEntityData.defineId(SunEntity.class, EntityDataSerializers.FLOAT);
    private static final float EXPLOSION_POWER = 28.0f;

    public boolean launched = false;
    public UUID owner;
    private int life = 0;
    private boolean exploded = false;

    public SunEntity(EntityType<? extends SunEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(SIZE, 2.0f);
    }

    public float getSize() {
        return this.entityData.get(SIZE);
    }

    public void setSize(float s) {
        this.entityData.set(SIZE, s);
    }

    public void launch(Vec3 velocity) {
        this.launched = true;
        this.noPhysics = false;
        this.setDeltaMovement(velocity);
    }

    @Override
    public boolean isNoGravity() {
        return true;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double d) {
        return true;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return this.getBoundingBox().inflate(24.0);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || !(this.level() instanceof ServerLevel level)) return;
        life++;
        float size = getSize();

        if (launched) {
            Vec3 v = getDeltaMovement();
            this.move(MoverType.SELF, v);
            level.sendParticles(ParticleTypes.FLAME, getX(), getY(), getZ(), 14, 1.2, 1.2, 1.2, 0.08);
            level.sendParticles(ParticleTypes.LAVA, getX(), getY(), getZ(), 2, 1.0, 1.0, 1.0, 0.0);
            if (this.horizontalCollision || this.verticalCollision || life > 160) {
                explode(level);
            }
            return;
        }

        // fogo ao redor enquanto é puxado + calor
        if (life % 2 == 0) {
            level.sendParticles(ParticleTypes.FLAME, getX(), getY(), getZ(), 8, size * 0.9, size * 0.9, size * 0.9, 0.05);
            level.sendParticles(ParticleTypes.LAVA, getX(), getY(), getZ(), 1, size * 0.7, size * 0.7, size * 0.7, 0.0);
        }
        if (life % 10 == 0 && size >= 4f) {
            double r = size * 3.0;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r),
                    x -> owner == null || !x.getUUID().equals(owner))) {
                if (e.distanceToSqr(this) < r * r) {
                    e.setSecondsOnFire(4);
                    e.hurt(level.damageSources().onFire(), 3.0f);
                }
            }
        }
    }

    private void explode(ServerLevel level) {
        if (exploded) return;
        exploded = true;
        Vec3 p = position();
        level.explode(this, p.x, p.y, p.z, EXPLOSION_POWER, true, Level.ExplosionInteraction.TNT);

        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.x, p.y, p.z, 8, 6, 3, 6, 0.0);
        level.sendParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 500, 8, 5, 8, 0.6);
        level.sendParticles(ParticleTypes.LAVA, p.x, p.y, p.z, 120, 8, 5, 8, 0.0);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 200, 8, 6, 8, 0.2);
        // ondas de choque
        for (int ring = 1; ring <= 3; ring++) {
            for (int i = 0; i < 40; i++) {
                double a = i * Math.PI * 2 / 40;
                level.sendParticles(ParticleTypes.CLOUD, p.x, p.y, p.z, 0,
                        Math.cos(a), 0.02, Math.sin(a), 0.6 * ring);
            }
        }
        level.playSound(null, p.x, p.y, p.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 10.0f, 0.5f);
        level.playSound(null, p.x, p.y, p.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 10.0f, 0.6f);
        level.playSound(null, p.x, p.y, p.z, SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 8.0f, 0.5f);
        Fx.near(level, p, 160, Fx.FLASH, 0);
        Fx.near(level, p, 160, Fx.SHAKE_BIG, 70);
        this.discard();
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
