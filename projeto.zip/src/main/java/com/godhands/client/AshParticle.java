package com.godhands.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** Cinza própria do mod (não é partícula do Minecraft): derrete ao vento. */
public class AshParticle extends TextureSheetParticle {
    protected AshParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        this.pickSprite(sprites);
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.lifetime = 40 + this.random.nextInt(40);
        this.quadSize = 0.05f + this.random.nextFloat() * 0.08f;
        float g = 0.12f + this.random.nextFloat() * 0.5f;
        this.rCol = g;
        this.gCol = g * 0.95f;
        this.bCol = g * 0.9f;
        if (this.random.nextInt(12) == 0) { // brasa
            this.rCol = 1.0f;
            this.gCol = 0.45f;
            this.bCol = 0.1f;
        }
        this.hasPhysics = false;
        this.friction = 0.96f;
        this.gravity = 0.0f;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public void tick() {
        super.tick();
        float t = this.age / (float) this.lifetime;
        this.alpha = t > 0.6f ? Math.max(0f, 1f - (t - 0.6f) / 0.4f) : 1f;
        this.yd += 0.0008;
        this.xd += (this.random.nextFloat() - 0.5f) * 0.004;
        this.zd += (this.random.nextFloat() - 0.5f) * 0.004;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new AshParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
}
