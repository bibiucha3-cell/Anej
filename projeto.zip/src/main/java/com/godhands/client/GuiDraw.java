package com.godhands.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

public class GuiDraw {
    /** Setor de anel. Ângulo 0 = topo, sentido horário. */
    public static void sector(GuiGraphics g, float cx, float cy, float r0, float r1, float a0, float a1, int argb) {
        Matrix4f m = g.pose().last().pose();
        int alpha = argb >>> 24 & 255, red = argb >> 16 & 255, green = argb >> 8 & 255, blue = argb & 255;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_COLOR);
        int steps = Math.max(8, (int) ((a1 - a0) * 24));
        for (int s = 0; s <= steps; s++) {
            float a = a0 + (a1 - a0) * s / steps;
            float sx = Mth.sin(a), sy = -Mth.cos(a);
            buf.vertex(m, cx + sx * r1, cy + sy * r1, 0).color(red, green, blue, alpha).endVertex();
            buf.vertex(m, cx + sx * r0, cy + sy * r0, 0).color(red, green, blue, alpha).endVertex();
        }
        Tesselator.getInstance().end();
        RenderSystem.disableBlend();
    }
}
