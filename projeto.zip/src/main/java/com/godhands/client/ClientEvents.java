package com.godhands.client;

import com.godhands.GodHandsMod;
import com.godhands.item.GodHandsItem;
import com.godhands.network.DistancePacket;
import com.godhands.network.ModNetwork;
import com.godhands.power.Power;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

@Mod.EventBusSubscriber(modid = GodHandsMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientEvents {
    private static final Random RNG = new Random();

    /** Scroll muda a distância da telecinese. */
    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null) return;
        if (GodHandsItem.usingPower(p) != Power.TELEKINESIS) return;
        double d = event.getScrollDelta();
        if (d == 0) return;
        event.setCanceled(true);
        ModNetwork.CH.sendToServer(new DistancePacket(d > 0 ? 1f : -1f));
    }

    /** Anula a lentidão de "usar item" para o jogador andar na velocidade normal. */
    @SubscribeEvent
    public static void onMove(MovementInputUpdateEvent event) {
        if (GodHandsItem.usingPower(event.getEntity()) != Power.NONE) {
            Input in = event.getInput();
            in.leftImpulse *= 5f;
            in.forwardImpulse *= 5f;
        }
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        float s = ClientFx.shake();
        if (s <= 0f) return;
        event.setYaw(event.getYaw() + (RNG.nextFloat() - 0.5f) * s);
        event.setPitch(event.getPitch() + (RNG.nextFloat() - 0.5f) * s);
        event.setRoll(event.getRoll() + (RNG.nextFloat() - 0.5f) * s * 2f);
    }
}
