package com.godhands.client;

import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

import java.util.Random;

/** Efeitos de tela: onda laranja (supervelocidade), azul (tempo), flash, glitch (realidade) e tremor. */
public class ClientFx {
    private static boolean slowOn, rewindOn;
    private static long slowT, slowOffT = -99999, rewindT, rewindOffT = -99999, pulseEnd;
    private static long flashT = -99999, realityT = -99999, shakeStart, shakeEnd;
    private static float shakePower;

    public static final IGuiOverlay OVERLAY = ClientFx::render;

    public static void handle(int type, int arg) {
        long now = Util.getMillis();
        switch (type) {
            case 0 -> { slowOn = true; slowT = now; }
            case 1 -> { slowOn = false; slowOffT = now; }
            case 2 -> flashT = now;
            case 3 -> { rewindOn = true; rewindT = now; }
            case 4 -> { rewindOn = false; rewindOffT = now; }
            case 5 -> realityT = now;
            case 6 -> startShake(now, arg, 0.6f);
            case 7 -> startShake(now, arg, 3.0f);
            case 8 -> { rewindT = now; pulseEnd = now + 1600; }
            default -> { }
        }
    }

    private static void startShake(long now, int ticks, float power) {
        shakeStart = now;
        shakeEnd = now + ticks * 50L;
        shakePower = power;
    }

    public static float shake() {
        long now = Util.getMillis();
        if (now >= shakeEnd) return 0f;
        float left = (shakeEnd - now) / (float) Math.max(1, shakeEnd - shakeStart);
        return shakePower * left;
    }

    private static void render(ForgeGui gui, GuiGraphics g, float pt, int w, int h) {
        long now = Util.getMillis();
        float cx = w / 2f, cy = h / 2f;
        float diag = (float) Math.sqrt(w * (double) w + h * (double) h) / 2f;

        // ---- supervelocidade: onda laranja-amarronzada ----
        float slowA = slowOn ? 1f : 1f - Mth.clamp((now - slowOffT) / 600f, 0f, 1f);
        if (slowA > 0f) {
            int col = ((int) (slowA * 85) << 24) | 0x964B14;
            float p = Mth.clamp((now - slowT) / 1000f, 0f, 1f);
            if (slowOn && p < 1f) {
                float r = p * diag * 1.05f;
                GuiDraw.sector(g, cx, cy, 0, r, 0, Mth.TWO_PI, col);
                GuiDraw.sector(g, cx, cy, Math.max(0, r - 14), r + 4, 0, Mth.TWO_PI,
                        ((int) (200 * (1f - p * 0.5f)) << 24) | 0xFFB45A);
            } else {
                g.fill(0, 0, w, h, col);
            }
            g.fillGradient(0, 0, w, h / 5, ((int) (slowA * 110) << 24) | 0x3A1A05, 0x003A1A05);
            g.fillGradient(0, h - h / 5, w, h, 0x003A1A05, ((int) (slowA * 110) << 24) | 0x3A1A05);
        }

        // ---- tempo: tom azul com linhas ----
        boolean rw = rewindOn || now < pulseEnd;
        float rwA = rw ? 1f : 1f - Mth.clamp((now - Math.max(rewindOffT, pulseEnd)) / 500f, 0f, 1f);
        if (rwA > 0f) {
            g.fill(0, 0, w, h, ((int) (rwA * 65) << 24) | 0x2A8CFF);
            for (int y = 0; y < h; y += 12) g.fill(0, y, w, y + 1, ((int) (rwA * 40) << 24) | 0x66E0FF);
            int band = (int) ((now / 3) % Math.max(1, h));
            g.fill(0, band, w, Math.min(h, band + 18), ((int) (rwA * 50) << 24) | 0xAAEEFF);
            float p = Mth.clamp((now - rewindT) / 900f, 0f, 1f);
            if (p < 1f) {
                float r = p * diag * 1.05f;
                GuiDraw.sector(g, cx, cy, Math.max(0, r - 12), r + 3, 0, Mth.TWO_PI,
                        ((int) (200 * (1f - p)) << 24) | 0x66E0FF);
            }
        }

        // ---- flash branco (explosão do sol) ----
        float ft = (now - flashT) / 1500f;
        if (ft >= 0f && ft < 1f) {
            int a = (int) (255 * (1f - ft) * (1f - ft));
            g.fill(0, 0, w, h, (a << 24) | 0xFFFFE8);
        }

        // ---- realidade: glitch ----
        float rt = (now - realityT) / 900f;
        if (rt >= 0f && rt < 1f) {
            float k = 1f - rt;
            g.fill(0, 0, w, h, ((int) (k * 70) << 24) | 0x8A2BE2);
            Random rnd = new Random(now / 60);
            for (int i = 0; i < 16; i++) {
                int y = rnd.nextInt(Math.max(1, h));
                int bh = 4 + rnd.nextInt(26);
                int off = rnd.nextInt(60) - 30;
                int c = (i % 2 == 0) ? 0xFF00FF : 0x00FFFF;
                g.fill(Math.max(0, off), y, w + Math.min(0, off), y + bh, ((int) (k * 120) << 24) | c);
            }
        }
    }
}
