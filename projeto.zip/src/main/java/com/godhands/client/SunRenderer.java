package com.godhands.client;

import com.godhands.entity.SunEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/** Sol: disco brilhante + halo + raios girando, sempre virado para a câmera (aditivo). */
public class SunRenderer extends EntityRenderer<SunEntity> {
    public SunRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public ResourceLocation getTextureLocation(SunEntity e) {
        return new ResourceLocation("textures/misc/white.png");
    }

    @Override
    public boolean shouldRender(SunEntity e, Frustum f, double x, double y, double z) {
        return true;
    }

    @Override
    public void render(SunEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float size = e.getSize();
        float time = e.tickCount + pt;
        float pulse = 1f + 0.04f * Mth.sin(time * 0.3f);

        ps.pushPose();
        ps.translate(0, e.getBbHeight() / 2f, 0);
        ps.mulPose(this.entityRenderDispatcher.cameraOrientation());
        Matrix4f m = ps.last().pose();
        VertexConsumer vc = buf.getBuffer(RenderType.lightning());

        // halo externo, halo médio, núcleo
        disc(vc, m, size * 5.0f * pulse, 1.0f, 0.45f, 0.08f, 0.30f, 2.2f);
        disc(vc, m, size * 2.4f * pulse, 1.0f, 0.70f, 0.20f, 0.65f, 1.8f);
        disc(vc, m, size * 1.0f * pulse, 1.0f, 1.0f, 0.88f, 1.00f, 0.8f);

        // raios girando
        int rays = 16;
        for (int i = 0; i < rays; i++) {
            float a = time * 0.02f + i * Mth.TWO_PI / rays;
            float len = size * (3.6f + 1.4f * Mth.sin(time * 0.1f + i * 1.7f));
            float r0 = size * 0.8f;
            float w = size * 0.18f;
            float cx = Mth.cos(a), cy = Mth.sin(a);
            float px = -cy, py = cx;
            vc.vertex(m, cx * r0 + px * w, cy * r0 + py * w, 0).color(1f, 0.85f, 0.4f, 0.45f).endVertex();
            vc.vertex(m, cx * len, cy * len, 0).color(1f, 0.5f, 0.1f, 0f).endVertex();
            vc.vertex(m, cx * len, cy * len, 0).color(1f, 0.5f, 0.1f, 0f).endVertex();
            vc.vertex(m, cx * r0 - px * w, cy * r0 - py * w, 0).color(1f, 0.85f, 0.4f, 0.45f).endVertex();
        }
        ps.popPose();
    }

    private static void disc(VertexConsumer vc, Matrix4f m, float radius, float r, float g, float b,
                             float maxAlpha, float falloff) {
        int rings = 12, seg = 36;
        for (int j = 0; j < rings; j++) {
            float t0 = j / (float) rings, t1 = (j + 1) / (float) rings;
            float a0 = maxAlpha * (float) Math.pow(1f - t0, falloff);
            float a1 = maxAlpha * (float) Math.pow(1f - t1, falloff);
            float g0 = Mth.lerp(t0, g, g * 0.6f), g1 = Mth.lerp(t1, g, g * 0.6f);
            float b0 = Mth.lerp(t0, b, b * 0.4f), b1 = Mth.lerp(t1, b, b * 0.4f);
            for (int k = 0; k < seg; k++) {
                float ang0 = k * Mth.TWO_PI / seg, ang1 = (k + 1) * Mth.TWO_PI / seg;
                float c0 = Mth.cos(ang0), s0 = Mth.sin(ang0), c1 = Mth.cos(ang1), s1 = Mth.sin(ang1);
                float ra = radius * t0, rb = radius * t1;
                vc.vertex(m, c0 * ra, s0 * ra, 0).color(r, g0, b0, a0).endVertex();
                vc.vertex(m, c0 * rb, s0 * rb, 0).color(r, g1, b1, a1).endVertex();
                vc.vertex(m, c1 * rb, s1 * rb, 0).color(r, g1, b1, a1).endVertex();
                vc.vertex(m, c1 * ra, s1 * ra, 0).color(r, g0, b0, a0).endVertex();
            }
        }
    }
}
