package com.godhands.item;

import com.godhands.client.ClientHooks;
import com.godhands.power.Power;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class GodHandsItem extends Item {
    public GodHandsItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    public static Power getPower(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag == null ? Power.NONE : Power.byId(tag.getInt("Power"));
    }

    public static void setPower(ItemStack stack, Power power) {
        stack.getOrCreateTag().putInt("Power", power.ordinal());
    }

    /** Poder selecionado em alguma das mãos. */
    public static boolean isHolding(Player player, Power power) {
        for (InteractionHand hand : InteractionHand.values()) {
            ItemStack s = player.getItemInHand(hand);
            if (s.getItem() instanceof GodHandsItem && getPower(s) == power) return true;
        }
        return false;
    }

    /** Poder que está sendo usado agora (botão direito segurado). */
    public static Power usingPower(LivingEntity entity) {
        if (entity.isUsingItem() && entity.getUseItem().getItem() instanceof GodHandsItem) {
            return getPower(entity.getUseItem());
        }
        return Power.NONE;
    }

    public static boolean hasInInventory(Player player) {
        for (ItemStack s : player.getInventory().items) if (s.getItem() instanceof GodHandsItem) return true;
        for (ItemStack s : player.getInventory().offhand) if (s.getItem() instanceof GodHandsItem) return true;
        return false;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.isShiftKeyDown()) {
            if (level.isClientSide) {
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openWheel(hand));
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        if (getPower(stack) == Power.NONE) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("msg.godhands.choose").withStyle(ChatFormatting.GRAY), true);
            }
            return InteractionResultHolder.pass(stack);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.NONE;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("tooltip.godhands.1").withStyle(ChatFormatting.AQUA));
        tips.add(Component.translatable("tooltip.godhands.2").withStyle(ChatFormatting.GRAY));
        Power p = getPower(stack);
        tips.add(Component.translatable("tooltip.godhands.power",
                Component.translatable("power.godhands." + p.key)).withStyle(ChatFormatting.GOLD));
    }
}
