package com.godhands.network;

import com.godhands.GodHandsMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String VERSION = "2";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GodHandsMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        int id = 0;
        CH.registerMessage(id++, SelectPowerPacket.class, SelectPowerPacket::encode,
                SelectPowerPacket::decode, SelectPowerPacket::handle);
        CH.registerMessage(id++, DistancePacket.class, DistancePacket::encode,
                DistancePacket::decode, DistancePacket::handle);
        CH.registerMessage(id++, FxPacket.class, FxPacket::encode,
                FxPacket::decode, FxPacket::handle);
    }
}
