package com.godhands.network;

import com.godhands.power.TelekinesisPower;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class DistancePacket {
    private final float delta;

    public DistancePacket(float delta) {
        this.delta = delta;
    }

    public static void encode(DistancePacket m, FriendlyByteBuf b) {
        b.writeFloat(m.delta);
    }

    public static DistancePacket decode(FriendlyByteBuf b) {
        return new DistancePacket(b.readFloat());
    }

    public static void handle(DistancePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) TelekinesisPower.adjustDistance(p, Math.max(-1f, Math.min(1f, m.delta)));
        });
        c.setPacketHandled(true);
    }
}
