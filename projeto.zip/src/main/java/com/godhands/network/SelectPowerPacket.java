package com.godhands.network;

import com.godhands.item.GodHandsItem;
import com.godhands.power.PowerManager;
import com.godhands.power.Power;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SelectPowerPacket {
    private final int power;
    private final boolean offHand;

    public SelectPowerPacket(int power, boolean offHand) {
        this.power = power;
        this.offHand = offHand;
    }

    public static void encode(SelectPowerPacket m, FriendlyByteBuf b) {
        b.writeVarInt(m.power);
        b.writeBoolean(m.offHand);
    }

    public static SelectPowerPacket decode(FriendlyByteBuf b) {
        return new SelectPowerPacket(b.readVarInt(), b.readBoolean());
    }

    public static void handle(SelectPowerPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p == null) return;
            ItemStack stack = p.getItemInHand(m.offHand ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
            if (!(stack.getItem() instanceof GodHandsItem)) return;
            Power power = Power.byId(m.power);
            GodHandsItem.setPower(stack, power);
            PowerManager.stop(p);
            p.displayClientMessage(Component.translatable("power.godhands." + power.key)
                    .withStyle(power == Power.NONE ? ChatFormatting.RED : ChatFormatting.AQUA), true);
            p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.BEACON_POWER_SELECT,
                    SoundSource.PLAYERS, 0.8f, 1.3f);
            if (power != Power.NONE) {
                p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                        SoundSource.PLAYERS, 0.9f, 1.6f);
                p.serverLevel().sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1.0, p.getZ(),
                        30, 0.5, 0.8, 0.5, 0.05);
            }
        });
        c.setPacketHandled(true);
    }
}
