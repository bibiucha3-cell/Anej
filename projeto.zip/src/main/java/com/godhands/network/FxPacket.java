package com.godhands.network;

import com.godhands.client.ClientFx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: efeitos de tela. */
public class FxPacket {
    public final int type;
    public final int arg;

    public FxPacket(int type, int arg) {
        this.type = type;
        this.arg = arg;
    }

    public static void encode(FxPacket m, FriendlyByteBuf b) {
        b.writeVarInt(m.type);
        b.writeVarInt(m.arg);
    }

    public static FxPacket decode(FriendlyByteBuf b) {
        return new FxPacket(b.readVarInt(), b.readVarInt());
    }

    public static void handle(FxPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientFx.handle(m.type, m.arg)));
        c.setPacketHandled(true);
    }
}
